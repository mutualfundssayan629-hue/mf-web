import { useState, useEffect } from 'react';
import { Language } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Funds from './components/Funds';
import WhyChoose from './components/WhyChoose';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  const [currentLang, setCurrentLang] = useState<Language>('en');

  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'smooth';
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Header currentLang={currentLang} onLanguageChange={setCurrentLang} />
      <Hero currentLang={currentLang} />
      <About currentLang={currentLang} />
      <Services currentLang={currentLang} />
      <Funds currentLang={currentLang} />
      <WhyChoose currentLang={currentLang} />
      <Contact currentLang={currentLang} />
      <Footer currentLang={currentLang} />
    </div>
  );
}

export default App;
console.log("reload");
console.log("reload");
