import { Language } from '../types';
import { translations } from '../translations';
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from 'lucide-react';

interface FooterProps {
  currentLang: Language;
}

export default function Footer({ currentLang }: FooterProps) {
  const t = translations[currentLang].footer;
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-2xl font-bold text-white mb-2">WealthGrowth</h3>
            <p className="text-emerald-400 font-semibold mb-4">Investments</p>
            <p className="text-gray-400 leading-relaxed">
              SEBI-certified mutual fund distributor committed to helping you achieve your financial goals through trusted investment strategies.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-4">{t.contact}</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <a href="tel:+919674225341" className="hover:text-emerald-400 transition-colors">
                  +91 96742 25341
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <a href="mailto:roy956326@gmail.com" className="hover:text-emerald-400 transition-colors break-all">
                  roy956326@gmail.com
                </a>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-4">{t.address}</h4>
            <div className="flex items-start space-x-3">
              <MapPin className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-1" />
              <p>
                Nalpur, Howrah<br />
                West Bengal – 711310
              </p>
            </div>

            <div className="flex space-x-4 mt-6">
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors transform hover:scale-110">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors transform hover:scale-110">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors transform hover:scale-110">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 text-center">
          <p className="text-gray-400">
            {currentYear} WealthGrowth Investments by Ranjit Roy. {t.copyright}
          </p>
          <p className="text-sm text-emerald-400 mt-2">
            SEBI Registered Mutual Fund Distributor
          </p>
        </div>
      </div>
    </footer>
  );
}
