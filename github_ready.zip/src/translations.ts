import { Translation } from './types';

export const translations: Record<string, Translation> = {
  en: {
    nav: {
      home: 'Home',
      about: 'About',
      services: 'Services',
      topFunds: 'Top Funds',
      contact: 'Contact'
    },
    hero: {
      title: 'Certified Mutual Fund Distributor',
      subtitle: 'Building wealth through trusted financial guidance. SEBI-certified expertise with a client-first approach for your secure financial future.',
      ctaPrimary: 'Contact Now',
      ctaSecondary: 'Explore Services'
    },
    about: {
      title: 'About Ranjit Roy',
      content: [
        'Ranjit Roy is a trusted Mutual Fund Distributor dedicated to helping families grow and protect their wealth. He specialises in SIP planning, long-term wealth creation, and personalised investment strategies.',
        'With a transparent and client-first approach, he simplifies financial decisions so investors can confidently achieve goals like retirement, child education, and future security.'
      ]
    },
    services: {
      title: 'Our Services',
      items: [
        {
          title: 'Mutual Fund Investment Planning',
          description: 'Customized portfolio strategies aligned with your financial goals and risk profile.'
        },
        {
          title: 'SIP Setup & Guidance',
          description: 'Systematic Investment Plans for disciplined wealth creation with rupee cost averaging benefits.'
        },
        {
          title: 'Retirement & Pension Planning',
          description: 'Build a secure retirement corpus through strategic long-term investments and pension funds.'
        },
        {
          title: 'Child Education & Future Planning',
          description: 'Ensure your child\'s bright future with dedicated education fund planning and investment strategies.'
        },
        {
          title: 'ELSS Tax Saving Options',
          description: 'Optimize your tax liability under Section 80C while building wealth through equity-linked savings schemes.'
        },
        {
          title: 'Portfolio Review & Rebalancing',
          description: 'Regular analysis and adjustment of your investment portfolio to maintain optimal asset allocation.'
        },
        {
          title: 'Risk Profiling & Goal-based Planning',
          description: 'Personalized assessment of your risk tolerance and creation of tailored investment roadmaps.'
        }
      ]
    },
    funds: {
      title: 'Fund Categories',
      categories: [
        {
          title: 'Equity Funds',
          description: 'Large cap, mid cap & small cap funds for high growth potential and long-term wealth creation.'
        },
        {
          title: 'Debt Funds',
          description: 'Stable returns with lower risk through bonds and fixed-income securities.'
        },
        {
          title: 'Hybrid Funds',
          description: 'Balanced Advantage & Aggressive Hybrid funds combining equity and debt for steady returns.'
        },
        {
          title: 'ELSS Tax Saver Funds',
          description: 'Equity investments with tax benefits under Section 80C with just 3-year lock-in period.'
        },
        {
          title: 'Liquid Funds',
          description: 'Short-term investment options with high liquidity and stable returns.'
        },
        {
          title: 'Thematic Funds',
          description: 'Specialized funds focusing on specific sectors and emerging opportunities.'
        }
      ]
    },
    topFunds: {
      title: 'Top 10 Popular Mutual Funds',
      items: [
        'Bluechip Equity Growth Fund',
        'Large & Midcap Growth Fund',
        'Flexi Cap Opportunities Fund',
        'ELSS Tax Saver Fund',
        'Balanced Advantage Fund',
        'Aggressive Hybrid Fund',
        'Midcap Diversified Fund',
        'Smallcap Opportunities Fund',
        'Short-Term Debt Fund',
        'Liquid Safe Fund'
      ]
    },
    whyChoose: {
      title: 'Why Choose Us',
      items: [
        {
          title: 'SEBI-compliant mutual fund products',
          description: 'All recommendations from SEBI-registered and regulated mutual fund houses.'
        },
        {
          title: 'Secure & transparent investment process',
          description: 'Complete transparency with secure digital documentation and tracking.'
        },
        {
          title: 'Personalized financial planning',
          description: 'Customized investment strategies tailored to your unique goals.'
        },
        {
          title: 'Zero hidden charges',
          description: 'Clear fee structure with no hidden costs. What you see is what you get.'
        },
        {
          title: 'Regular portfolio reviews',
          description: 'Continuous monitoring and optimization of your investment portfolio.'
        },
        {
          title: 'Fast & reliable support',
          description: 'Responsive customer service when you need assistance with investments.'
        }
      ]
    },
    contactForm: {
      title: 'Get In Touch',
      namePlaceholder: 'Your Name',
      phonePlaceholder: 'Your Phone Number',
      emailPlaceholder: 'Your Email (Optional)',
      messagePlaceholder: 'Your Message (Optional)',
      submitButton: 'Send Message',
      successMessage: 'Thank you! We will contact you soon.',
      errorMessage: 'Something went wrong. Please try again.'
    },
    footer: {
      contact: 'Contact Information',
      address: 'Address',
      copyright: 'All rights reserved.',
      company: 'WealthGrowth Investments'
    }
  },
  hi: {
    nav: {
      home: 'होम',
      about: 'हमारे बारे में',
      services: 'सेवाएं',
      topFunds: 'टॉप फंड्स',
      contact: 'संपर्क करें'
    },
    hero: {
      title: 'प्रमाणित म्यूचुअल फंड वितरक',
      subtitle: 'विश्वसनीय वित्तीय मार्गदर्शन के माध्यम से धन निर्माण। आपके सुरक्षित वित्तीय भविष्य के लिए SEBI-प्रमाणित विशेषज्ञता।',
      ctaPrimary: 'अभी संपर्क करें',
      ctaSecondary: 'सेवाएं देखें'
    },
    about: {
      title: 'रंजीत रॉय के बारे में',
      content: [
        'वित्तीय योजना और निवेश सलाहकार में वर्षों के समर्पित अनुभव के साथ, मैं व्यक्तियों और परिवारों को रणनीतिक म्यूचुअल फंड निवेश के माध्यम से उनके वित्तीय लक्ष्यों को प्राप्त करने में मदद करता हूं।',
        'एक SEBI-प्रमाणित म्यूचुअल फंड वितरक के रूप में, मैं पारदर्शी, नैतिक और व्यक्तिगत निवेश समाधान प्रदान करने के लिए प्रतिबद्ध हूं। मेरा दृष्टिकोण आपकी अनूठी वित्तीय स्थिति, जोखिम क्षमता और दीर्घकालिक उद्देश्यों को समझने पर केंद्रित है।',
        'मैं विश्वास पर आधारित स्थायी संबंध बनाने और लगातार परिणाम देने में विश्वास करता हूं। चाहे आप सेवानिवृत्ति, अपने बच्चे की शिक्षा, या धन सृजन की योजना बना रहे हों, मैं सिद्ध रणनीतियों और निष्पक्ष सलाह के साथ हर कदम पर आपका मार्गदर्शन करने के लिए यहां हूं।'
      ]
    },
    services: {
      title: 'हमारी सेवाएं',
      items: [
        {
          title: 'म्यूचुअल फंड निवेश योजना',
          description: 'आपके वित्तीय लक्ष्यों और जोखिम प्रोफाइल के अनुरूप अनुकूलित पोर्टफोलियो रणनीतियां।'
        },
        {
          title: 'SIP सेटअप और मार्गदर्शन',
          description: 'रुपये की लागत औसत लाभ के साथ अनुशासित धन सृजन के लिए व्यवस्थित निवेश योजनाएं।'
        },
        {
          title: 'सेवानिवृत्ति योजना',
          description: 'रणनीतिक दीर्घकालिक निवेश और पेंशन फंड के माध्यम से एक सुरक्षित सेवानिवृत्ति कोष बनाएं।'
        },
        {
          title: 'बाल शिक्षा योजना',
          description: 'समर्पित शिक्षा निधि योजना और निवेश रणनीतियों के साथ अपने बच्चे के उज्ज्वल भविष्य को सुनिश्चित करें।'
        },
        {
          title: 'टैक्स बचत (ELSS)',
          description: 'इक्विटी-लिंक्ड बचत योजनाओं के माध्यम से धन बनाते हुए धारा 80C के तहत अपनी कर देयता को अनुकूलित करें।'
        },
        {
          title: 'पोर्टफोलियो समीक्षा और पुनर्संतुलन',
          description: 'इष्टतम परिसंपत्ति आवंटन बनाए रखने के लिए आपके निवेश पोर्टफोलियो का नियमित विश्लेषण और समायोजन।'
        }
      ]
    },
    funds: {
      title: 'शीर्ष म्यूचुअल फंड श्रेणियां',
      categories: [
        {
          title: 'इक्विटी फंड',
          description: 'दीर्घकालिक धन सृजन के लिए शेयरों में निवेश के माध्यम से उच्च विकास क्षमता।'
        },
        {
          title: 'डेट फंड',
          description: 'बॉन्ड और फिक्स्ड-इनकम सिक्योरिटीज में निवेश के माध्यम से कम जोखिम के साथ स्थिर रिटर्न।'
        },
        {
          title: 'हाइब्रिड फंड',
          description: 'मध्यम जोखिम और स्थिर रिटर्न के लिए इक्विटी और डेट को मिलाकर संतुलित दृष्टिकोण।'
        },
        {
          title: 'ELSS टैक्स सेवर फंड',
          description: 'केवल 3 साल की लॉक-इन अवधि के साथ धारा 80C के तहत कर लाभ के साथ इक्विटी निवेश।'
        }
      ]
    },
    whyChoose: {
      title: 'हमें क्यों चुनें',
      items: [
        {
          title: 'SEBI-अनुपालन उत्पाद',
          description: 'सभी सिफारिशें SEBI-पंजीकृत और विनियमित म्यूचुअल फंड हाउसों से हैं।'
        },
        {
          title: 'सुरक्षित और पारदर्शी',
          description: 'सुरक्षित डिजिटल दस्तावेज़ीकरण और ट्रैकिंग के साथ प्रक्रियाओं में पूर्ण पारदर्शिता।'
        },
        {
          title: 'व्यक्तिगत योजना',
          description: 'आपके अनूठे लक्ष्यों और परिस्थितियों के अनुरूप अनुकूलित वित्तीय रणनीतियां।'
        },
        {
          title: 'कोई छिपी हुई फीस नहीं',
          description: 'बिना किसी छिपी लागत के स्पष्ट शुल्क संरचना। जो आप देखते हैं वही आपको मिलता है।'
        },
        {
          title: '24/7 ग्राहक सहायता',
          description: 'जब भी आपको अपने निवेश के साथ सहायता की आवश्यकता हो, समर्पित सहायता।'
        },
        {
          title: 'सिद्ध ट्रैक रिकॉर्ड',
          description: 'ग्राहकों को सफलतापूर्वक उनके वित्तीय उद्देश्यों को प्राप्त करने में मदद करने का वर्षों का अनुभव।'
        }
      ]
    },
    contactForm: {
      title: 'संपर्क में रहें',
      namePlaceholder: 'आपका नाम',
      phonePlaceholder: 'आपका फोन नंबर',
      emailPlaceholder: 'आपका ईमेल (वैकल्पिक)',
      messagePlaceholder: 'आपका संदेश (वैकल्पिक)',
      submitButton: 'संदेश भेजें',
      successMessage: 'धन्यवाद! हम जल्द ही आपसे संपर्क करेंगे।',
      errorMessage: 'कुछ गलत हो गया। कृपया पुनः प्रयास करें।'
    },
    footer: {
      contact: 'संपर्क जानकारी',
      address: 'पता',
      copyright: 'सर्वाधिकार सुरक्षित।'
    }
  },
  bn: {
    nav: {
      home: 'হোম',
      about: 'আমাদের সম্পর্কে',
      services: 'সেবা',
      topFunds: 'টপ ফান্ড',
      contact: 'যোগাযোগ'
    },
    hero: {
      title: 'প্রত্যয়িত মিউচুয়াল ফান্ড পরিবেশক',
      subtitle: 'বিশ্বস্ত আর্থিক নির্দেশনার মাধ্যমে সম্পদ তৈরি। আপনার সুরক্ষিত আর্থিক ভবিষ্যতের জন্য SEBI-প্রত্যয়িত দক্ষতা।',
      ctaPrimary: 'এখনই যোগাযোগ করুন',
      ctaSecondary: 'সেবা দেখুন'
    },
    about: {
      title: 'রঞ্জিত রায় সম্পর্কে',
      content: [
        'আর্থিক পরিকল্পনা এবং বিনিয়োগ পরামর্শে বছরের নিবেদিত অভিজ্ঞতার সাথে, আমি ব্যক্তি এবং পরিবারগুলিকে কৌশলগত মিউচুয়াল ফান্ড বিনিয়োগের মাধ্যমে তাদের আর্থিক লক্ষ্য অর্জনে সহায়তা করি।',
        'একজন SEBI-প্রত্যয়িত মিউচুয়াল ফান্ড পরিবেশক হিসাবে, আমি স্বচ্ছ, নৈতিক এবং ব্যক্তিগত বিনিয়োগ সমাধান প্রদানের জন্য প্রতিশ্রুতিবদ্ধ। আমার পদ্ধতি আপনার অনন্য আর্থিক পরিস্থিতি, ঝুঁকি ক্ষমতা এবং দীর্ঘমেয়াদী উদ্দেশ্যগুলি বোঝার উপর দৃষ্টি নিবদ্ধ করে।',
        'আমি বিশ্বাসের উপর ভিত্তি করে দীর্ঘস্থায়ী সম্পর্ক তৈরি এবং ধারাবাহিক ফলাফল প্রদানে বিশ্বাস করি। আপনি অবসর, আপনার সন্তানের শিক্ষা বা সম্পদ সৃষ্টির জন্য পরিকল্পনা করছেন কিনা, প্রমাণিত কৌশল এবং নিরপেক্ষ পরামর্শের সাথে প্রতিটি পদক্ষেপে আপনাকে গাইড করতে আমি এখানে আছি।'
      ]
    },
    services: {
      title: 'আমাদের সেবাসমূহ',
      items: [
        {
          title: 'মিউচুয়াল ফান্ড বিনিয়োগ পরিকল্পনা',
          description: 'আপনার আর্থিক লক্ষ্য এবং ঝুঁকি প্রোফাইলের সাথে সামঞ্জস্যপূর্ণ কাস্টমাইজড পোর্টফোলিও কৌশল।'
        },
        {
          title: 'SIP সেটআপ এবং নির্দেশনা',
          description: 'রুপি খরচ গড় সুবিধা সহ শৃঙ্খলাবদ্ধ সম্পদ সৃষ্টির জন্য পদ্ধতিগত বিনিয়োগ পরিকল্পনা।'
        },
        {
          title: 'অবসর পরিকল্পনা',
          description: 'কৌশলগত দীর্ঘমেয়াদী বিনিয়োগ এবং পেনশন তহবিলের মাধ্যমে একটি সুরক্ষিত অবসর তহবিল তৈরি করুন।'
        },
        {
          title: 'শিশু শিক্ষা পরিকল্পনা',
          description: 'নিবেদিত শিক্ষা তহবিল পরিকল্পনা এবং বিনিয়োগ কৌশল দিয়ে আপনার সন্তানের উজ্জ্বল ভবিষ্যত নিশ্চিত করুন।'
        },
        {
          title: 'কর সাশ্রয় (ELSS)',
          description: 'ইক্যুইটি-লিঙ্কড সেভিংস স্কিমের মাধ্যমে সম্পদ তৈরি করার সাথে সাথে ধারা 80C এর অধীনে আপনার কর দায় অনুকূল করুন।'
        },
        {
          title: 'পোর্টফোলিও পর্যালোচনা এবং পুনঃভারসাম্য',
          description: 'সর্বোত্তম সম্পদ বরাদ্দ বজায় রাখতে আপনার বিনিয়োগ পোর্টফোলিওর নিয়মিত বিশ্লেষণ এবং সমন্বয়।'
        }
      ]
    },
    funds: {
      title: 'শীর্ষ মিউচুয়াল ফান্ড বিভাগ',
      categories: [
        {
          title: 'ইক্যুইটি ফান্ড',
          description: 'দীর্ঘমেয়াদী সম্পদ সৃষ্টির জন্য স্টকে বিনিয়োগের মাধ্যমে উচ্চ বৃদ্ধির সম্ভাবনা।'
        },
        {
          title: 'ডেট ফান্ড',
          description: 'বন্ড এবং ফিক্সড-ইনকাম সিকিউরিটিতে বিনিয়োগের মাধ্যমে কম ঝুঁকিতে স্থিতিশীল রিটার্ন।'
        },
        {
          title: 'হাইব্রিড ফান্ড',
          description: 'মাঝারি ঝুঁকি এবং স্থির রিটার্নের জন্য ইক্যুইটি এবং ডেট একত্রিত করে সুষম পদ্ধতি।'
        },
        {
          title: 'ELSS ট্যাক্স সেভার ফান্ড',
          description: 'মাত্র 3 বছরের লক-ইন পিরিয়ড সহ ধারা 80C এর অধীনে কর সুবিধা সহ ইক্যুইটি বিনিয়োগ।'
        }
      ]
    },
    whyChoose: {
      title: 'কেন আমাদের বেছে নিন',
      items: [
        {
          title: 'SEBI-অনুগত পণ্য',
          description: 'সমস্ত সুপারিশ SEBI-নিবন্ধিত এবং নিয়ন্ত্রিত মিউচুয়াল ফান্ড হাউস থেকে।'
        },
        {
          title: 'সুরক্ষিত এবং স্বচ্ছ',
          description: 'সুরক্ষিত ডিজিটাল ডকুমেন্টেশন এবং ট্র্যাকিং সহ প্রক্রিয়ায় সম্পূর্ণ স্বচ্ছতা।'
        },
        {
          title: 'ব্যক্তিগত পরিকল্পনা',
          description: 'আপনার অনন্য লক্ষ্য এবং পরিস্থিতির জন্য উপযুক্ত কাস্টমাইজড আর্থিক কৌশল।'
        },
        {
          title: 'কোন লুকানো চার্জ নেই',
          description: 'কোন লুকানো খরচ ছাড়াই স্পষ্ট ফি কাঠামো। আপনি যা দেখেন তা-ই পাবেন।'
        },
        {
          title: '24/7 গ্রাহক সহায়তা',
          description: 'যখনই আপনার বিনিয়োগে সহায়তার প্রয়োজন হয় তখন নিবেদিত সহায়তা।'
        },
        {
          title: 'প্রমাণিত ট্র্যাক রেকর্ড',
          description: 'ক্লায়েন্টদের সফলভাবে তাদের আর্থিক লক্ষ্য অর্জনে সহায়তা করার বছরের অভিজ্ঞতা।'
        }
      ]
    },
    contactForm: {
      title: 'যোগাযোগ করুন',
      namePlaceholder: 'আপনার নাম',
      phonePlaceholder: 'আপনার ফোন নম্বর',
      emailPlaceholder: 'আপনার ইমেইল (ঐচ্ছিক)',
      messagePlaceholder: 'আপনার বার্তা (ঐচ্ছিক)',
      submitButton: 'বার্তা পাঠান',
      successMessage: 'ধন্যবাদ! আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব।',
      errorMessage: 'কিছু ভুল হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।'
    },
    footer: {
      contact: 'যোগাযোগের তথ্য',
      address: 'ঠিকানা',
      copyright: 'সর্বস্বত্ব সংরক্ষিত।'
    }
  }
};
